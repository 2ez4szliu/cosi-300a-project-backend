module.exports = Object.freeze({
    CLUSTER_NAME:'cosi300a-backend',
	USERNAME: 'shizhaoliu',
	PASSWORD: 'liushizhao123',
	DBNAME: 'submission_data'
});
