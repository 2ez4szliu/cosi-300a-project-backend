module.exports = Object.freeze({
	TOKEN_SECRET: 'mysimplesecret'
});
